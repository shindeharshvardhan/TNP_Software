import React from "react";

function Followup() {
  return (
    <div className="h-full w-full flex flex-col justify-center items-center text-neutral-950 gap-3">
      Followup
    </div>
  );
}

export default Followup;
