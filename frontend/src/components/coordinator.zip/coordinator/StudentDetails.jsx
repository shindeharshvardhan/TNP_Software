import React from 'react'

function StudentDetails() {
  return (
    <div className='h-full w-full flex flex-col justify-start items-center text-neutral-950 gap-3 pt-16'>StudentDetails</div>
  )
}

export default StudentDetails